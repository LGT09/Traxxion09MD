railway init
railway up
