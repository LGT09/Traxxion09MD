run = "node bot/index.js"
language = "nodejs"
entrypoint = "bot/index.js"
