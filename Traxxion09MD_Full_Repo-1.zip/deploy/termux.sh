pkg update -y && pkg install nodejs git -y
git clone https://github.com/YOUR_GITHUB/Traxxion09MD.git
cd Traxxion09MD
npm install
node bot/index.js
