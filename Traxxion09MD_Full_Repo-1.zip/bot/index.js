const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const qrcode = require("qrcode-terminal");
const axios = require("axios");
require("dotenv").config();

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState("auth_info");
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const jid = msg.key.remoteJid;

        if (text === "!ping") {
            await sock.sendMessage(jid, { text: "pong!" });
        } else if (text.startsWith("!yt ")) {
            const query = text.slice(4);
            const ytResponse = await axios.get(`https://yt-downloader-api-v1.onrender.com/search?q=${encodeURIComponent(query)}`);
            const video = ytResponse.data?.videos?.[0];
            if (video) {
                await sock.sendMessage(jid, { text: `*${video.title}*
${video.url}` });
            } else {
                await sock.sendMessage(jid, { text: "No results found." });
            }
        } else if (text.startsWith("!ask ")) {
            const prompt = text.slice(5);
            const openaiRes = await axios.post("https://api.openai.com/v1/completions", {
                model: "text-davinci-003",
                prompt,
                max_tokens: 100
            }, {
                headers: {
                    "Authorization": `Bearer ${process.env.OPENAI_KEY}`,
                    "Content-Type": "application/json"
                }
            });
            await sock.sendMessage(jid, { text: openaiRes.data.choices[0].text.trim() });
        }
    });
}

startBot();
