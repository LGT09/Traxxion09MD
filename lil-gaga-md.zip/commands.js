const config = require("./config")
const { getRandomQuote, getRandomJoke, getRandomFact } = require("./utils")

// Command handler function
async function processCommand(sock, message, command, args) {
  const chatId = message.key.remoteJid
  const sender = message.key.participant || chatId
  const isOwner = config.OWNER_NUMBERS.includes(sender.split("@")[0])

  // Basic commands
  switch (command) {
    case "help":
      return getHelpMessage()

    case "about":
      return getAboutMessage()

    case "owner":
      return getOwnerInfo()

    case "quote":
      return await getRandomQuote()

    case "joke":
      return await getRandomJoke()

    case "fact":
      return await getRandomFact()

    case "sticker":
      return await createSticker(sock, message, args)

    // Owner only commands
    case "broadcast":
      if (isOwner) {
        return await broadcastMessage(sock, args.join(" "))
      }
      return "Sorry, only the owner can use this command."

    case "restart":
      if (isOwner) {
        await sock.sendMessage(chatId, { text: "Restarting bot..." })
        process.exit(0) // This will restart the bot if you're using a process manager like PM2
      }
      return "Sorry, only the owner can use this command."

    default:
      return `Unknown command: ${command}. Type !help to see available commands.`
  }
}

// Help message function
function getHelpMessage() {
  return `*🤖 Lil Gaga-md Bot Commands 🤖*

*Basic Commands:*
!help - Show this help message
!about - About this bot
!owner - Get owner information
!quote - Get a random quote
!joke - Get a random joke
!fact - Get a random fact
!sticker - Convert image to sticker

*Owner Commands:*
!broadcast [message] - Broadcast a message
!restart - Restart the bot

_created by Lil Gaga Traxx 09_`
}

// About message function
function getAboutMessage() {
  return `*🤖 About Lil Gaga-md Bot 🤖*

A multi-purpose WhatsApp bot created with ❤️

*Version:* 1.0.0
*Creator:* Lil Gaga Traxx 09
*Library:* Baileys

_created by Lil Gaga Traxx 09_`
}

// Owner info function
function getOwnerInfo() {
  return `*👑 Owner Information 👑*

*Name:* Lil Gaga Traxx 09
*Number:* wa.me/263780078177
*Alternative:* wa.me/263716857999

_created by Lil Gaga Traxx 09_`
}

// Create sticker function
async function createSticker(sock, message, args) {
  try {
    const quoted = message.message.extendedTextMessage?.contextInfo?.quotedMessage

    if (!quoted) {
      return "Please reply to an image with !sticker to convert it to a sticker"
    }

    // Check if the quoted message contains an image
    if (!quoted.imageMessage) {
      return "Please reply to an image to convert it to a sticker"
    }

    const media = await sock.downloadMediaMessage(message.message.extendedTextMessage.contextInfo.quotedMessage)

    await sock.sendMessage(message.key.remoteJid, { sticker: media }, { quoted: message })

    return null // No text response needed as we sent a sticker
  } catch (error) {
    console.error("Error creating sticker:", error)
    return "Failed to create sticker. Please try again."
  }
}

// Broadcast message function
async function broadcastMessage(sock, broadcastMessage) {
  if (!broadcastMessage) {
    return "Please provide a message to broadcast"
  }

  try {
    const chats = await sock.groupFetchAllParticipating()
    const groups = Object.entries(chats).map((entry) => entry[0])

    let successCount = 0

    for (const group of groups) {
      await sock.sendMessage(group, {
        text: `*📢 BROADCAST MESSAGE 📢*\n\n${broadcastMessage}\n\n_created by Lil Gaga Traxx 09_`,
      })
      successCount++
    }

    return `Successfully sent broadcast to ${successCount} groups`
  } catch (error) {
    console.error("Error broadcasting message:", error)
    return "Failed to broadcast message. Please try again."
  }
}

module.exports = {
  processCommand,
}
