# Lil Gaga-md WhatsApp Bot

A multi-purpose WhatsApp bot created by Lil Gaga Traxx 09.

## Features

- 🚀 Fast and efficient
- 🔄 Auto reconnect
- 📱 Multi-device support
- 🔐 Pairing code support
- 🎭 Sticker creation
- 🎮 Fun commands
- 📢 Broadcast messages
- 🛠️ And much more!

## Installation

### Prerequisites

- [Node.js](https://nodejs.org/) (v14 or higher)
- [Git](https://git-scm.com/)

### Installation on Termux

1. Open Termux app
2. Run the following commands:

\`\`\`bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs git ffmpeg libwebp imagemagick
git clone https://github.com/yourusername/lil-gaga-md.git
cd lil-gaga-md
npm install
npm start
\`\`\`

### Installation on Linux/macOS/Windows

1. Make sure you have Node.js installed
2. Run the following commands:

\`\`\`bash
git clone https://github.com/yourusername/lil-gaga-md.git
cd lil-gaga-md
npm install
npm start
\`\`\`

### Quick Installation (Using the install script)

\`\`\`bash
curl -s https://raw.githubusercontent.com/yourusername/lil-gaga-md/main/install.sh | bash
\`\`\`

## Usage

1. Scan the QR code or enter the pairing code when prompted
2. Start using the bot with the prefix `!`

## Commands

- `!help` - Show help message
- `!about` - About this bot
- `!owner` - Get owner information
- `!quote` - Get a random quote
- `!joke` - Get a random joke
- `!fact` - Get a random fact
- `!sticker` - Convert image to sticker

## Owner Commands

- `!broadcast [message]` - Broadcast a message to all groups
- `!restart` - Restart the bot

## Configuration

Edit the `config.js` file to customize the bot settings:

\`\`\`javascript
module.exports = {
    BOT_NAME: 'Lil Gaga-md',
    PREFIX: '!',
    SESSION_ID: 'LilGagaMD',
    PHONE_NUMBER: '263780078177',
    OWNER_NUMBERS: ['263780078177', '263716857999'],
    // ... other settings
};
\`\`\`

## Contact

- Owner: Lil Gaga Traxx 09
- WhatsApp: [+263780078177](https://wa.me/263780078177)
- Alternative: [+263716857999](https://wa.me/263716857999)

## License

This project is licensed under the MIT License.

---

_created by Lil Gaga Traxx 09_
