module.exports = {
  // Bot configuration
  BOT_NAME: "Lil Gaga-md",
  PREFIX: "!",
  SESSION_ID: "LilGagaMD",
  PHONE_NUMBER: "263780078177", // Without the + sign

  // Owner information
  OWNER_NUMBERS: ["263780078177", "263716857999"],
  OWNER_NAME: "Lil Gaga Traxx 09",

  // Bot features configuration
  ENABLE_WELCOME_MESSAGE: true,
  ENABLE_GOODBYE_MESSAGE: true,
  ENABLE_AUTO_READ: true,

  // Welcome and goodbye messages
  WELCOME_MESSAGE: "Welcome to the group! I am Lil Gaga-md bot. Use !help to see available commands.",
  GOODBYE_MESSAGE: "Goodbye! Hope to see you again.",

  // Auto response messages
  AUTO_RESPONSES: {
    hi: "Hello there! How can I help you today?",
    hello: "Hi! I'm Lil Gaga-md bot. Type !help to see what I can do!",
  },
}
