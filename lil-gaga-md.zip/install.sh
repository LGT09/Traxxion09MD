#!/bin/bash

echo "╭───────────────────────────────────────╮"
echo "│           Lil Gaga-md Bot             │"
echo "│      created by Lil Gaga Traxx 09     │"
echo "╰───────────────────────────────────────╯"

# Check if running on Termux
if [ -d "/data/data/com.termux" ]; then
  echo "📱 Running on Termux..."
  
  # Update packages
  echo "🔄 Updating packages..."
  pkg update -y
  pkg upgrade -y
  
  # Install required packages
  echo "📦 Installing required packages..."
  pkg install -y nodejs git ffmpeg libwebp imagemagick
  
  # Clone the repository
  echo "📥 Cloning the repository..."
  git clone https://github.com/yourusername/lil-gaga-md.git
  
  # Navigate to the project directory
  cd lil-gaga-md
  
  # Install dependencies
  echo "📦 Installing dependencies..."
  npm install
  
  # Start the bot
  echo "🚀 Starting the bot..."
  npm start
else
  echo "💻 Running on standard Linux/macOS..."
  
  # Check if Node.js is installed
  if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
  fi
  
  # Clone the repository
  echo "📥 Cloning the repository..."
  git clone https://github.com/yourusername/lil-gaga-md.git
  
  # Navigate to the project directory
  cd lil-gaga-md
  
  # Install dependencies
  echo "📦 Installing dependencies..."
  npm install
  
  # Start the bot
  echo "🚀 Starting the bot..."
  npm start
fi
