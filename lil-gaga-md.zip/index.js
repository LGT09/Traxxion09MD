const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
} = require("@whiskeysockets/baileys")
const pino = require("pino")
const { Boom } = require("@hapi/boom")
const fs = require("fs")
const path = require("path")
const { processCommand } = require("./commands")
const { banner, getRandomMessage } = require("./utils")
const config = require("./config")
const qrcode = require("qrcode-terminal")
const readline = require("readline")

// Store to save the chat history
const store = makeInMemoryStore({ logger: pino().child({ level: "silent", stream: "store" }) })

// Function to handle WhatsApp connection
async function connectToWhatsApp() {
  banner()
  console.log("🤖 Starting Lil Gaga-md Bot...")

  const { state, saveCreds } = await useMultiFileAuthState("session_" + config.SESSION_ID)
  const { version } = await fetchLatestBaileysVersion()

  console.log(`⚡ Using WA v${version.join(".")}`)

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: ["Lil Gaga-md", "Chrome", "1.0.0"],
  })

  store.bind(sock.ev)

  // Handle connection update events
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr) {
      console.log("⚡ Scan the QR code below to login:")
      qrcode.generate(qr, { small: true })

      // Setup for pairing code
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
      })

      rl.question("Enter pairing code (or press Enter to use QR): ", async (code) => {
        if (code && code.length > 0) {
          try {
            console.log("⚡ Attempting to pair with code:", code)
            await sock.requestPairingCode(config.PHONE_NUMBER)
            console.log("✅ Pairing code sent to your phone!")
          } catch (error) {
            console.error("❌ Error with pairing code:", error)
          }
        }
        rl.close()
      })
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error instanceof Boom
          ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
          : true

      console.log("❌ Connection closed due to:", lastDisconnect?.error)

      if (shouldReconnect) {
        console.log("⚡ Reconnecting...")
        connectToWhatsApp()
      } else {
        console.log("❌ Connection closed. You are logged out.")
      }
    } else if (connection === "open") {
      console.log("✅ Connected to WhatsApp!")
      console.log("🤖 Lil Gaga-md Bot is now online!")
    }
  })

  // Save credentials whenever they are updated
  sock.ev.on("creds.update", saveCreds)

  // Handle incoming messages
  sock.ev.on("messages.upsert", async ({ messages }) => {
    for (const message of messages) {
      if (!message.key.fromMe && message.message) {
        await handleIncomingMessage(sock, message)
      }
    }
  })
}

// Function to handle incoming messages
async function handleIncomingMessage(sock, message) {
  try {
    const chatId = message.key.remoteJid
    const messageType = Object.keys(message.message)[0]

    // Get the message content
    let messageContent = ""
    if (messageType === "conversation") {
      messageContent = message.message.conversation
    } else if (messageType === "extendedTextMessage") {
      messageContent = message.message.extendedTextMessage.text
    } else {
      // Handle other message types if needed
      return
    }

    // Check if the message is a command (starts with prefix)
    if (messageContent.startsWith(config.PREFIX)) {
      const command = messageContent.slice(config.PREFIX.length).trim().split(" ")[0].toLowerCase()
      const args = messageContent.slice(config.PREFIX.length).trim().split(" ").slice(1)

      console.log(`📩 Command received: ${command} with args: ${args.join(" ")}`)

      // Process the command
      const response = await processCommand(sock, message, command, args)

      // Add signature to the response if it exists
      if (response) {
        const signedResponse = `${response}\n\n_created by Lil Gaga Traxx 09_`

        await sock.sendMessage(chatId, { text: signedResponse }, { quoted: message })
      }
    }
  } catch (error) {
    console.error("❌ Error handling message:", error)
  }
}

// Start the bot
connectToWhatsApp()
