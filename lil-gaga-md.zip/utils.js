const axios = require("axios")
const chalk = require("chalk")

// Function to display banner
function banner() {
  console.log(
    chalk.green(`
    ╭━━━╮╱╱╱╱╱╱╱╱╱╭━━━╮╱╱╱╱╱╱╱╱╱╭━━━╮
    ┃╭━╮┃╱╱╱╱╱╱╱╱╱┃╭━╮┃╱╱╱╱╱╱╱╱╱┃╭━╮┃
    ┃┃╱┃┣╮╭┫╭╮╱╭╮╱┃┃╱╰╋━━┫╭━━┫╭━╮┃╰━━┫╭━━┫╭╮
    ┃┃╱┃┃┃┃┃┃┃╱┃┃╱┃┃╱╭┫╭╮┃┃╭╮┃┃╭┫╰━━╮┃╭╮┃╰╯
    ┃╰━╯┃╰╯┃╰╯╱┃╰╮┃╰━╯┃╰╯┃┃╰╯┃┃┃┃┃╰━╯┃╰╯┃╭╮
    ╰━━━┻━━┻━━╮┣━╯╰━━━┻━━┻┻━━┻╯╰╯╰━━━┻━━┻╯╰╯
    ╱╱╱╱╱╱╱╭━╯┃
    ╱╱╱╱╱╱╱╰━━╯
    `),
  )
  console.log(chalk.yellow("╭───────────────────────────────────────╮"))
  console.log(chalk.yellow("│           Lil Gaga-md Bot             │"))
  console.log(chalk.yellow("│      created by Lil Gaga Traxx 09     │"))
  console.log(chalk.yellow("╰───────────────────────────────────────╯"))
}

// Function to get random quotes
async function getRandomQuote() {
  try {
    const response = await axios.get("https://api.quotable.io/random")
    return `*Quote:* ${response.data.content}\n\n*Author:* ${response.data.author}`
  } catch (error) {
    console.error("Error fetching quote:", error)
    return "Failed to fetch a quote. Please try again later."
  }
}

// Function to get random jokes
async function getRandomJoke() {
  try {
    const response = await axios.get("https://official-joke-api.appspot.com/random_joke")
    return `*Joke:* ${response.data.setup}\n\n*Punchline:* ${response.data.punchline}`
  } catch (error) {
    console.error("Error fetching joke:", error)
    return "Failed to fetch a joke. Please try again later."
  }
}

// Function to get random facts
async function getRandomFact() {
  try {
    const response = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en")
    return `*Random Fact:* ${response.data.text}`
  } catch (error) {
    console.error("Error fetching fact:", error)
    return "Failed to fetch a fact. Please try again later."
  }
}

// Function to get random messages for responses
function getRandomMessage() {
  const messages = [
    "I'm here to help!",
    "How can I assist you today?",
    "Need anything else?",
    "I'm Lil Gaga-md, your friendly bot!",
    "Type !help to see what I can do!",
  ]

  return messages[Math.floor(Math.random() * messages.length)]
}

module.exports = {
  banner,
  getRandomQuote,
  getRandomJoke,
  getRandomFact,
  getRandomMessage,
}
