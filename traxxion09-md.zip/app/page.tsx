"use client"

import  from "../index"

export default function SyntheticV0PageForDeployment() {
  return < />
}