# Traxxion09-md - Advanced WhatsApp Bot

A powerful, feature-rich WhatsApp bot built with Node.js and Baileys library, designed for easy deployment across multiple platforms.

## 🚀 Features

- **Multi-Device Support**: Works with WhatsApp Web multi-device
- **Command System**: Extensible command framework with prefix support
- **Group Management**: Admin commands for group moderation
- **Media Handling**: Support for images, videos, and documents
- **Auto-Reply**: Intelligent message responses
- **Web Dashboard**: Monitor bot status via web interface
- **Multi-Platform Deployment**: Deploy on Vercel, Railway, Heroku, VPS, etc.

## 📋 Commands

### General Commands
- `.help` - Show available commands
- `.ping` - Check bot response time
- `.info` - Bot information
- `.owner` - Owner contact

### Group Commands
- `.tagall` - Tag all group members
- `.groupinfo` - Get group information
- `.rules` - Show group rules

### Fun Commands
- `.joke` - Random joke
- `.quote` - Inspirational quote

### Admin Commands (Group Admins Only)
- `.kick @user` - Remove user from group
- `.promote @user` - Make user admin
- `.demote @user` - Remove admin privileges

## 🛠️ Installation

### Local Development

1. **Clone the repository**
   \`\`\`bash
   git clone https://github.com/yourusername/traxxion09-md.git
   cd traxxion09-md
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Configure environment**
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your configuration
   \`\`\`

4. **Start the bot**
   \`\`\`bash
   npm start
   \`\`\`

5. **Scan QR Code**
   - Visit `http://localhost:3000/qr`
   - Scan with WhatsApp

### Docker Deployment

\`\`\`bash
# Build and run with Docker
docker build -t traxxion09-md .
docker run -p 3000:3000 traxxion09-md

# Or use Docker Compose
docker-compose up -d
\`\`\`

## 🌐 Deployment Platforms

### 1. Railway
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template)

1. Fork this repository
2. Connect to Railway
3. Set environment variables
4. Deploy!

### 2. Vercel
\`\`\`bash
npm i -g vercel
vercel --prod
\`\`\`

### 3. Heroku
\`\`\`bash
# Install Heroku CLI
heroku create traxxion09-md
heroku config:set NODE_ENV=production
git push heroku main
\`\`\`

### 4. VPS/Server
\`\`\`bash
# Clone and setup
git clone https://github.com/yourusername/traxxion09-md.git
cd traxxion09-md
npm install --production
npm start

# Use PM2 for process management
npm install -g pm2
pm2 start index.js --name traxxion09-md
pm2 startup
pm2 save
\`\`\`

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PREFIX` | Command prefix | `.` |
| `OWNER` | Owner phone number | `1234567890` |
| `PORT` | Server port | `3000` |
| `NODE_ENV` | Environment | `development` |

### Custom Commands

Add new commands in the `commands` object:

\`\`\`javascript
commands.newcommand = {
  description: 'Description of new command',
  execute: async (sock, msg, args) => {
    // Command logic here
    await sock.sendMessage(msg.key.remoteJid, { text: 'Response' })
  }
}
\`\`\`

## 📱 Usage

1. **Add bot to group** or **start private chat**
2. **Send `.help`** to see available commands
3. **Use commands** with the configured prefix (default: `.`)

## 🔧 Troubleshooting

### Common Issues

1. **QR Code not showing**
   - Check if port 3000 is accessible
   - Visit `/qr` endpoint directly

2. **Bot not responding**
   - Verify WhatsApp connection
   - Check console logs for errors

3. **Commands not working**
   - Ensure correct prefix is used
   - Check if bot has necessary permissions

### Logs

\`\`\`bash
# View logs (if using PM2)
pm2 logs traxxion09-md

# Docker logs
docker logs container_name
\`\`\`

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Baileys](https://github.com/WhiskeySockets/Baileys) - WhatsApp Web API
- [Express.js](https://expressjs.com/) - Web framework
- [Node.js](https://nodejs.org/) - Runtime environment

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/traxxion09-md/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/traxxion09-md/discussions)
- **Contact**: [WhatsApp](https://wa.me/1234567890)

---

**⭐ Star this repository if you found it helpful!**
