import { makeWASocket, DisconnectReason, useMultiFileAuthState } from "@baileys/md"
import { Boom } from "@hapi/boom"
import express from "express"
import pino from "pino"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Initialize Express app
const app = express()
const PORT = process.env.PORT || 3000

// Bot configuration
const BOT_NAME = "Traxxion09-md"
const PREFIX = process.env.PREFIX || "."
const OWNER = process.env.OWNER || "1234567890"

// Logger configuration
const logger = pino({ level: "silent" })

// Store active connections
const sock = null
let qrCode = null

// Middleware
app.use(express.json())
app.use(express.static("public"))

// Routes
app.get("/", (req, res) => {
  res.json({
    status: "active",
    bot: BOT_NAME,
    message: "WhatsApp Bot is running!",
    qr: qrCode ? "QR Code available at /qr" : "Bot is connected",
  })
})

app.get("/qr", (req, res) => {
  if (qrCode) {
    res.send(`
      <html>
        <head><title>${BOT_NAME} - QR Code</title></head>
        <body style="display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #f0f0f0;">
          <div style="text-align: center; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h2>${BOT_NAME}</h2>
            <p>Scan this QR code with WhatsApp</p>
            <img src="data:image/png;base64,${qrCode}" alt="QR Code" style="max-width: 300px;">
            <p><small>Refresh page if QR code expires</small></p>
          </div>
        </body>
      </html>
    `)
  } else {
    res.json({ message: "No QR code available. Bot might be connected." })
  }
})

// Bot commands
const commands = {
  help: {
    description: "Show available commands",
    execute: async (sock, msg) => {
      const helpText = `
🤖 *${BOT_NAME} Commands*

*General Commands:*
${PREFIX}help - Show this help menu
${PREFIX}ping - Check bot response time
${PREFIX}info - Bot information
${PREFIX}owner - Owner contact

*Group Commands:*
${PREFIX}tagall - Tag all group members
${PREFIX}groupinfo - Get group information
${PREFIX}rules - Show group rules

*Fun Commands:*
${PREFIX}joke - Random joke
${PREFIX}quote - Inspirational quote

*Admin Commands:*
${PREFIX}kick @user - Remove user from group
${PREFIX}promote @user - Make user admin
${PREFIX}demote @user - Remove admin privileges

_Bot developed with ❤️_
      `
      await sock.sendMessage(msg.key.remoteJid, { text: helpText })
    },
  },

  ping: {
    description: "Check bot response time",
    execute: async (sock, msg) => {
      const start = Date.now()
      const sent = await sock.sendMessage(msg.key.remoteJid, { text: "Pinging..." })
      const end = Date.now()

      await sock.sendMessage(msg.key.remoteJid, {
        text: `🏓 Pong!\nResponse time: ${end - start}ms`,
        edit: sent.key,
      })
    },
  },

  info: {
    description: "Bot information",
    execute: async (sock, msg) => {
      const info = `
🤖 *${BOT_NAME} Information*

*Version:* 1.0.0
*Platform:* Node.js
*Library:* Baileys
*Uptime:* ${formatUptime(process.uptime())}
*Memory Usage:* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB

*Features:*
✅ Multi-device support
✅ Group management
✅ Media handling
✅ Auto-reply
✅ Command system

_Developed by Traxxion Team_
      `
      await sock.sendMessage(msg.key.remoteJid, { text: info })
    },
  },

  owner: {
    description: "Owner contact",
    execute: async (sock, msg) => {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `👨‍💻 *Bot Owner*\n\nContact: wa.me/${OWNER}`,
        contextInfo: {
          externalAdReply: {
            title: "Contact Owner",
            body: "Click to chat with bot owner",
            thumbnailUrl: "https://via.placeholder.com/300x300.png?text=Owner",
            sourceUrl: `https://wa.me/${OWNER}`,
          },
        },
      })
    },
  },

  tagall: {
    description: "Tag all group members",
    execute: async (sock, msg) => {
      if (!msg.key.remoteJid.endsWith("@g.us")) {
        return await sock.sendMessage(msg.key.remoteJid, { text: "❌ This command can only be used in groups!" })
      }

      try {
        const groupMetadata = await sock.groupMetadata(msg.key.remoteJid)
        const participants = groupMetadata.participants

        let text = `📢 *Group Announcement*\n\n`
        const mentions = []

        participants.forEach((participant) => {
          text += `@${participant.id.split("@")[0]} `
          mentions.push(participant.id)
        })

        await sock.sendMessage(msg.key.remoteJid, {
          text: text,
          mentions: mentions,
        })
      } catch (error) {
        await sock.sendMessage(msg.key.remoteJid, { text: "❌ Failed to tag members. Make sure bot is admin." })
      }
    },
  },

  joke: {
    description: "Random joke",
    execute: async (sock, msg) => {
      const jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "Why did the scarecrow win an award? He was outstanding in his field!",
        "Why don't eggs tell jokes? They'd crack each other up!",
        "What do you call a fake noodle? An impasta!",
        "Why did the math book look so sad? Because it had too many problems!",
      ]

      const randomJoke = jokes[Math.floor(Math.random() * jokes.length)]
      await sock.sendMessage(msg.key.remoteJid, { text: `😂 *Random Joke*\n\n${randomJoke}` })
    },
  },

  quote: {
    description: "Inspirational quote",
    execute: async (sock, msg) => {
      const quotes = [
        "The only way to do great work is to love what you do. - Steve Jobs",
        "Innovation distinguishes between a leader and a follower. - Steve Jobs",
        "Life is what happens to you while you're busy making other plans. - John Lennon",
        "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
        "It is during our darkest moments that we must focus to see the light. - Aristotle",
      ]

      const randomQuote = quotes[Math.floor(Math.random() * quotes.length)]
      await sock.sendMessage(msg.key.remoteJid, { text: `💭 *Inspirational Quote*\n\n${randomQuote}` })
    },
  },
}

// Utility functions
function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)

  return `${days}d ${hours}h ${minutes}m ${secs}s`
}

function isOwner(jid) {
  return jid.split("@")[0] === OWNER
}

// WhatsApp connection function
async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState("auth_info_baileys")

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
    logger,
    browser: [BOT_NAME, "Chrome", "1.0.0"],
  })

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr) {
      qrCode = qr
      console.log("QR Code generated. Visit /qr to scan.")
    }

    if (connection === "close") {
      const shouldReconnect = (lastDisconnect?.error instanceof Boom)?.output?.statusCode !== DisconnectReason.loggedOut
      console.log("Connection closed due to ", lastDisconnect?.error, ", reconnecting ", shouldReconnect)

      if (shouldReconnect) {
        connectToWhatsApp()
      }
    } else if (connection === "open") {
      console.log(`${BOT_NAME} connected successfully!`)
      qrCode = null
    }
  })

  sock.ev.on("creds.update", saveCreds)

  // Message handler
  sock.ev.on("messages.upsert", async (m) => {
    const msg = m.messages[0]
    if (!msg.message || msg.key.fromMe) return

    const messageText =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      ""

    // Command handling
    if (messageText.startsWith(PREFIX)) {
      const args = messageText.slice(PREFIX.length).trim().split(" ")
      const commandName = args.shift().toLowerCase()

      if (commands[commandName]) {
        try {
          console.log(`Executing command: ${commandName}`)
          await commands[commandName].execute(sock, msg, args)
        } catch (error) {
          console.error(`Error executing command ${commandName}:`, error)
          await sock.sendMessage(msg.key.remoteJid, {
            text: "❌ An error occurred while executing the command.",
          })
        }
      }
    }

    // Auto-reply for specific messages
    const lowerText = messageText.toLowerCase()
    if (lowerText.includes("hello") || lowerText.includes("hi")) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `Hello! 👋 I'm ${BOT_NAME}. Type ${PREFIX}help to see available commands.`,
      })
    }
  })
}

// Start the bot
async function startBot() {
  try {
    console.log(`Starting ${BOT_NAME}...`)
    await connectToWhatsApp()

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
      console.log(`Bot: ${BOT_NAME}`)
      console.log(`Prefix: ${PREFIX}`)
    })
  } catch (error) {
    console.error("Failed to start bot:", error)
    process.exit(1)
  }
}

// Handle process termination
process.on("SIGINT", () => {
  console.log("\nShutting down bot...")
  if (sock) {
    sock.end()
  }
  process.exit(0)
})

// Start the application
startBot()
